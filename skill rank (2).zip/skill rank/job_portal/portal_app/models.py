from django.db import models
import json

class Job(models.Model):
    job_id = models.IntegerField(unique=True)
    title = models.CharField(max_length=255)
    company = models.CharField(max_length=100, default="Tech Company")
    location = models.CharField(max_length=100, default="San Francisco, CA")
    description = models.TextField()
    skills = models.TextField(blank=True, null=True)  # JSON string of skills
    
    def __str__(self):
        return f"{self.title} at {self.company}"

class Candidate(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    resume_text = models.TextField()
    skills = models.TextField(blank=True, null=True)  # JSON string of skills
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class Match(models.Model):
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    match_score = models.FloatField()
    matching_skills = models.TextField()  # JSON string
    missing_skills = models.TextField()  # JSON string
    explanation = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.candidate.name} - {self.job.title}: {self.match_score}%"