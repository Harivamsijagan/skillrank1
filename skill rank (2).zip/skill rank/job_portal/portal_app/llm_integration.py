import openai
import json
import os

# Set your OpenAI API key here or in environment variables
openai.api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")

def extract_skills_from_text(text):
    """Use LLM to extract skills from text"""
    prompt = f"""
    Extract technical skills, programming languages, frameworks, tools, and technologies from the following text.
    Return ONLY a JSON array of skills without any additional text.
    
    Text: {text[:3000]}  # Limit text length to avoid token limits
    """
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that extracts skills from text and returns only JSON arrays."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1
        )
        
        skills_text = response.choices[0].message.content.strip()
        # Clean up the response to ensure it's valid JSON
        if skills_text.startswith('```json'):
            skills_text = skills_text[7:-3].strip()
        elif skills_text.startswith('```'):
            skills_text = skills_text[3:-3].strip()
            
        skills = json.loads(skills_text)
        return skills
    except Exception as e:
        print(f"Error extracting skills: {e}")
        # Fallback to a simple keyword-based approach
        return simple_skill_extraction(text)

def simple_skill_extraction(text):
    """Simple fallback skill extraction without LLM"""
    skills_keywords = [
        'python', 'javascript', 'java', 'c++', 'c#', 'php', 'ruby', 'go', 'rust',
        'react', 'angular', 'vue', 'django', 'flask', 'spring', 'node.js',
        'aws', 'azure', 'google cloud', 'docker', 'kubernetes', 'jenkins',
        'sql', 'mysql', 'postgresql', 'mongodb', 'redis',
        'machine learning', 'ai', 'data analysis', 'nlp', 'computer vision'
    ]
    
    found_skills = []
    text_lower = text.lower()
    for skill in skills_keywords:
        if skill in text_lower:
            found_skills.append(skill)
            
    return found_skills

def calculate_match(candidate_skills, job_skills):
    """Calculate match percentage between candidate and job skills"""
    if not job_skills:
        return 0, [], []
    
    candidate_skills_set = set(candidate_skills)
    job_skills_set = set(job_skills)
    
    matching_skills = list(candidate_skills_set.intersection(job_skills_set))
    missing_skills = list(job_skills_set.difference(candidate_skills_set))
    
    if not job_skills_set:
        match_percentage = 0
    else:
        match_percentage = round((len(matching_skills) / len(job_skills_set)) * 100, 2)
    
    return match_percentage, matching_skills, missing_skills

def generate_explanation(candidate_skills, job_skills, match_percentage, matching_skills, missing_skills):
    """Generate explanation for the match results"""
    if match_percentage > 80:
        strength = "excellent"
    elif match_percentage > 60:
        strength = "good"
    elif match_percentage > 40:
        strength = "moderate"
    else:
        strength = "weak"
    
    explanation = f"This is a {strength} match. "
    
    if matching_skills:
        explanation += f"The candidate has {len(matching_skills)} of the {len(job_skills)} required skills. "
        explanation += f"Strong matches include: {', '.join(matching_skills[:3])}. "
    
    if missing_skills:
        explanation += f"Missing skills include: {', '.join(missing_skills[:3])}."
    
    return explanation