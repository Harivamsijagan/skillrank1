from django.urls import path
from . import views

urlpatterns = [
    path('', views.job_list, name='job_list'),
    path('upload/', views.upload_resume, name='upload_resume'),
    path('recommendations/<int:candidate_id>/', views.recommendations, name='recommendations'),
]