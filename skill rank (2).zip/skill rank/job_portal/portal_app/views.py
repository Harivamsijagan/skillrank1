from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Job, Candidate, Match
from .llm_integration import extract_skills_from_text, calculate_match, generate_explanation
import requests
import json
from PyPDF2 import PdfReader
import os

def fetch_jobs_from_api():
    """Fetch jobs from the JSONPlaceholder API and adapt them as job listings"""
    try:
        response = requests.get('https://jsonplaceholder.typicode.com/posts')
        posts = response.json()
        
        # Clear existing jobs to avoid duplicates
        Job.objects.all().delete()
        
        companies = ["TechFlow Solutions", "DataVision Inc", "StartupLab", "AI Innovations Corp", "CloudTech Solutions"]
        locations = ["San Francisco, CA", "New York, NY", "Austin, TX", "Seattle, WA", "Boston, MA"]
        
        for i, post in enumerate(posts[:50]):  # Limit to 50 jobs
            company = companies[i % len(companies)]
            location = locations[i % len(locations)]
            
            job, created = Job.objects.get_or_create(
                job_id=post['id'],
                defaults={
                    'title': post['title'][:50] + " Developer" if len(post['title']) > 10 else "Software Developer",
                    'company': company,
                    'location': location,
                    'description': post['body']
                }
            )
            
            # Extract skills from job description if not already done
            if not job.skills:
                skills = extract_skills_from_text(post['body'])
                job.skills = json.dumps(skills)
                job.save()
                
    except Exception as e:
        print(f"Error fetching jobs: {e}")

def job_list(request):
    """Display job listings with search functionality"""
    # Fetch jobs from API if none exist
    if Job.objects.count() == 0:
        fetch_jobs_from_api()
    
    jobs = Job.objects.all()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        jobs = jobs.filter(title__icontains=search_query)
    
    # Filter by location
    location_filter = request.GET.get('location', '')
    if location_filter:
        jobs = jobs.filter(location__icontains=location_filter)
    
    # Filter by company
    company_filter = request.GET.get('company', '')
    if company_filter:
        jobs = jobs.filter(company__icontains=company_filter)
    
    context = {
        'jobs': jobs,
        'search_query': search_query,
        'location_filter': location_filter,
        'company_filter': company_filter,
    }
    return render(request, 'job_list.html', context)

def upload_resume(request):
    """Handle resume upload and processing"""
    if request.method == 'POST' and request.FILES.get('resume'):
        resume_file = request.FILES['resume']
        
        # Extract text from PDF
        try:
            pdf_reader = PdfReader(resume_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            
            # Extract candidate name and email from text
            name = "Candidate"
            email = "candidate@example.com"
            
            lines = text.split('\n')
            for line in lines:
                if '@' in line and '.' in line and ' ' not in line:
                    email = line.strip()
                elif any(word in line.lower() for word in ['email', 'e-mail']):
                    parts = line.split(':')
                    if len(parts) > 1:
                        email = parts[1].strip()
            
            # Look for name in first few lines
            for i in range(min(5, len(lines))):
                if lines[i].strip() and not any(keyword in lines[i].lower() for keyword in 
                                              ['phone', 'email', 'linkedin', 'github', 'http']):
                    name = lines[i].strip()
                    break
            
            # Create candidate record
            candidate = Candidate.objects.create(
                name=name,
                email=email,
                resume_text=text
            )
            
            # Extract skills from resume
            skills = extract_skills_from_text(text)
            candidate.skills = json.dumps(skills)
            candidate.save()
            
            # Generate matches for all jobs
            generate_matches(candidate)
            
            return redirect('recommendations', candidate_id=candidate.id)
            
        except Exception as e:
            error_message = f"Error processing resume: {str(e)}"
            return render(request, 'upload_resume.html', {'error_message': error_message})
    
    return render(request, 'upload_resume.html')

def generate_matches(candidate):
    """Generate matches between candidate and all jobs"""
    candidate_skills = json.loads(candidate.skills) if candidate.skills else []
    
    for job in Job.objects.all():
        job_skills = json.loads(job.skills) if job.skills else []
        
        match_percentage, matching_skills, missing_skills = calculate_match(
            candidate_skills, job_skills
        )
        
        explanation = generate_explanation(
            candidate_skills, job_skills, match_percentage, matching_skills, missing_skills
        )
        
        # Create match record
        Match.objects.create(
            candidate=candidate,
            job=job,
            match_score=match_percentage,
            matching_skills=json.dumps(matching_skills),
            missing_skills=json.dumps(missing_skills),
            explanation=explanation
        )

def recommendations(request, candidate_id):
    """Display job recommendations for a candidate"""
    candidate = Candidate.objects.get(id=candidate_id)
    matches = Match.objects.filter(candidate=candidate).order_by('-match_score')
    
    # Process match data for template
    for match in matches:
        match.matching_skills_list = json.loads(match.matching_skills)[:5]  # Show top 5 matching skills
        match.missing_skills_list = json.loads(match.missing_skills)[:5]    # Show top 5 missing skills
    
    context = {
        'candidate': candidate,
        'matches': matches,
    }
    return render(request, 'recommendations.html', context)